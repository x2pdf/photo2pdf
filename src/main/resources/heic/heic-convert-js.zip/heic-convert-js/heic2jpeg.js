const { promisify } = require("util");
const fs = require("fs");
const convert = require("heic-convert");

(async () => {
    var param = process.argv[2].split('=');
    var from = param[0];
    var to = param[1];

    console.log(`from: ${from}`)
    console.log(`to: ${to}`)

    const inputBuffer = await promisify(fs.readFile)(from);
    const outputBuffer = await convert({
      buffer: inputBuffer, // the HEIC file buffer
      format: 'JPEG',        // output format
      quality: 1      
    });
  
    await promisify(fs.writeFile)(to, outputBuffer);
 
})();
