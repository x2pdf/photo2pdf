const { promisify } = require("util");
const fs = require("fs");
const convert = require("heic-convert");

(async () => {
    var param = process.argv[2].split('=');
    var from = param[0];
    var to = param[1];
	var quality = process.argv[3];
	if(quality=="" || quality==null || quality==undefined){
		console.log(`quality == null`)
		quality = 1;
	}

    console.log(`from: ${from}`)
    console.log(`to: ${to}`)
    console.log(`quality: ${quality}`)

    const inputBuffer = await promisify(fs.readFile)(from);
    const outputBuffer = await convert({
      buffer: inputBuffer, // the HEIC file buffer
      format: 'JPEG',        // output format
      quality: quality      
    });
  
    await promisify(fs.writeFile)(to, outputBuffer);
 
})();
