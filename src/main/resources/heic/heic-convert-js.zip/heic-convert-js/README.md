# heic2jpg
reference: https://github.com/Alatr/heic2jpg
# 详情请参考以上链接的项目。